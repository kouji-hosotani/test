require 'test_helper'

class TruliaTrend::IsspHelperTest < ActionView::TestCase
end
