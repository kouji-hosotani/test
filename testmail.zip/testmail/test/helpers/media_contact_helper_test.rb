require 'test_helper'

class MediaContactHelperTest < ActionView::TestCase
end
