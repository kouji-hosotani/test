require 'test_helper'

class MobileCarrierHelperTest < ActionView::TestCase
end
