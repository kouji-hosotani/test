require 'test_helper'

class MediaPathAnalysis::IsspHelperTest < ActionView::TestCase
end
