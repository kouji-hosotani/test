require 'test_helper'

class RegisterRouteHelperTest < ActionView::TestCase
end
