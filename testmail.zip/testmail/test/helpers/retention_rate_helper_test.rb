require 'test_helper'

class RetentionRateHelperTest < ActionView::TestCase
end
