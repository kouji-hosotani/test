require 'test_helper'

class CustomerJourneyHelperTest < ActionView::TestCase
end
