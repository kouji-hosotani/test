require 'test_helper'

class Trulia::IsspHelperTest < ActionView::TestCase
end
