require 'test_helper'

class UsageDistributionHelperTest < ActionView::TestCase
end
