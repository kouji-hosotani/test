require 'test_helper'

class BatchJobTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
