require 'test_helper'

class ProtocolTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
