require 'test_helper'

class TicketModeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
