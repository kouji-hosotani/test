require 'test_helper'

class UrlTitleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
