require 'test_helper'

class AuthTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
