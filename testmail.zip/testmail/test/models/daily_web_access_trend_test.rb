require 'test_helper'

class DailyWebAccessTrendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
