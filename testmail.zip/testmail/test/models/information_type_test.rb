require 'test_helper'

class InformationTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
