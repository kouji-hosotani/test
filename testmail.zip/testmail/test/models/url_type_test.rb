require 'test_helper'

class UrlTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
