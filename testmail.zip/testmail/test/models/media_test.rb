require 'test_helper'

class MediaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
