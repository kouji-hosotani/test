require 'test_helper'

class CacheHourlyWebAccessTrendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
