require 'test_helper'

class UsageDistributionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
