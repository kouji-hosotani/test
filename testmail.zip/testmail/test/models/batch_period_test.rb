require 'test_helper'

class BatchPeriodTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
