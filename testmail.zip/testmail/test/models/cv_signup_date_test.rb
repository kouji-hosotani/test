require 'test_helper'

class CvSignupDateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
