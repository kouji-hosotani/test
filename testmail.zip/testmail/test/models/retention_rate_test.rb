require 'test_helper'

class RetentionRateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
