require 'test_helper'

class EncodeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
