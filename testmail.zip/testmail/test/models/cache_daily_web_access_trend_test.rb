require 'test_helper'

class CacheDailyWebAccessTrendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
