require 'test_helper'

class BatchUrlTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
