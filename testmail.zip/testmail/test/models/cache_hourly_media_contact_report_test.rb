require 'test_helper'

class CacheHourlyMediaContactReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
