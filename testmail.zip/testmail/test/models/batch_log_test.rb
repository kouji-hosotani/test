require 'test_helper'

class BatchLogTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
