require 'test_helper'

class HourlyMediaContactReportTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
