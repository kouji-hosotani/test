require 'test_helper'

class StatusTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
