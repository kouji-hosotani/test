require 'test_helper'

class SuffixTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
