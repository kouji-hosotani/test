require 'test_helper'

class TruliaTrend::IsspControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
