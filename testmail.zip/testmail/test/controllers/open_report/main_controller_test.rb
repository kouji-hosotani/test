require 'test_helper'

class OpenReport::MainControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
