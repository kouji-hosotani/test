require 'test_helper'

class Trulia::IsspControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
