require 'test_helper'

class MailHistory::MainControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
