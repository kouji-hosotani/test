require 'test_helper'

class MailReservation::MainControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
