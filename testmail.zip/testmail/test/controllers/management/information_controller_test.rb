require 'test_helper'

class Management::InformationControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
