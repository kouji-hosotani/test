require 'test_helper'

class Management::UupvControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
