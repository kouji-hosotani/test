require 'test_helper'

class Management::BaseControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
