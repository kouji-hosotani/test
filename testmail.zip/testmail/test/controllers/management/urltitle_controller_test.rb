require 'test_helper'

class Management::UrltitleControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
