require 'test_helper'

class Management::UnitControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
