require 'test_helper'

class Management::StationControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
