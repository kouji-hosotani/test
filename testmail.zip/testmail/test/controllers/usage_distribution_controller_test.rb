require 'test_helper'

class UsageDistributionControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
