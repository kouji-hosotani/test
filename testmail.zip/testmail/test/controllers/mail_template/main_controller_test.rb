require 'test_helper'

class MailTemplate::MainControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
