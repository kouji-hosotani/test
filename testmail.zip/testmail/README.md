Testmail
====

## Description

  Testmail is a Training Tools using Mail

## Demo

![Logo](app/assets/images/logos/newton_logo.jpg "Testmail")

## Requirement
* ruby 2.2.3
* rails 4.2.6
* jquery 2.1.0 or later

## Licence

## Author
