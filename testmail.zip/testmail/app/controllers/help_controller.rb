class HelpController < ApplicationController
 
  def index
    @test = "hoge"
  end

  def download
  end

end
