class Protocol < ActiveRecord::Base
end
