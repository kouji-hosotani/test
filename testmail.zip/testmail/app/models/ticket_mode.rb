class TicketMode < ActiveRecord::Base
  has_many :tickets
end
