class OpenStatus < ActiveRecord::Base
  NOT_OPEN = 1
  OPEN     = 2
end
