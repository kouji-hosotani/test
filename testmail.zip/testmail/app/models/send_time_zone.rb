class SendTimeZone < ActiveRecord::Base
end
