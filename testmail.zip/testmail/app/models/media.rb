class Media < ActiveRecord::Base
  has_many :url_titles
end
