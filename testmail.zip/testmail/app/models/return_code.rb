class ReturnCode < ActiveRecord::Base
end
