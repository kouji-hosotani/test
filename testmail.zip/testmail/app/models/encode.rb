class Encode < ActiveRecord::Base
end
