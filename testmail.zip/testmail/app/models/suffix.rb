class Suffix < ActiveRecord::Base
  has_one :batch_url
end
