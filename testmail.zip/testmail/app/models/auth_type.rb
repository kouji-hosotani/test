class AuthType < ActiveRecord::Base
  has_many :profile
end
