module MailTemplate::MainHelper
end
