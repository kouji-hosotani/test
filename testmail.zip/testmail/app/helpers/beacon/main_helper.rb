module Beacon::MainHelper
end
